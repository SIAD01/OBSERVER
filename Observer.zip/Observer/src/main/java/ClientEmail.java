public class ClientEmail implements Observer {
    private final String email;

    public ClientEmail(String email) {
        this.email = email;
    }

    @Override
    public void notifier(String produit) {
        System.out.println("Email envoye a " + email
                + " : Le produit " + produit + " est disponible.");
    }
}
