import java.util.*;

public class Magasin {
    private final Map<String, List<Observer>> demandes =
            new HashMap<>();

    public void demanderProduit(String produit, Observer client) {
        demandes.computeIfAbsent(
                produit.toLowerCase(),
                k -> new ArrayList<>()
        ).add(client);

        System.out.println("Demande enregistree : " + produit);
    }

    public void recevoirProduit(String produit) {
        System.out.println("\nMagasin recoit : " + produit);

        List<Observer> clients =
                demandes.remove(produit.toLowerCase());

        if (clients == null || clients.isEmpty()) {
            System.out.println("Aucun client en attente.");
            return;
        }

        for (Observer client : clients) {
            client.notifier(produit);
        }
    }
}