public class ClientSMS implements Observer {
    private final String telephone;

    public ClientSMS(String telephone) {
        this.telephone = telephone;
    }

    @Override
    public void notifier(String produit) {
        System.out.println("SMS envoye au " + telephone
                + " : Le produit " + produit + " est disponible.");
    }
}
