public class Main {
    
    public static void main(String[] args) {
        Magasin magasin = new Magasin();

        Observer ali = new ClientEmail("ali@gmail.com");
        Observer sara = new ClientSMS("0550000001");
        Observer karim = new ClientEmail("karim@gmail.com");

        magasin.demanderProduit("iPhone", ali);
        magasin.demanderProduit("Ordinateur", sara);
        magasin.demanderProduit("iPhone", karim);

        magasin.recevoirProduit("iPhone");

        magasin.recevoirProduit("Ordinateur");

        magasin.recevoirProduit("Samsung");
    }
}