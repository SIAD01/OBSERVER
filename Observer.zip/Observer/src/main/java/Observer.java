public interface Observer {
    void notifier(String produit);
}
